# Problem Statement: Create a user sign up with authentication using JWT and Passport

1. Read the request from front end.
2. Hash the password using bcrypt.
3. Create a user sign up with authentication using JWT and Passport
