module.exports = {
    jwtSecret: "s0m3$3Cret$h0lyC0d3&$",
    jwtSession: {
        session: false
    }
};