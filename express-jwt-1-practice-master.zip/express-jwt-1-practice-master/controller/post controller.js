exports.get_post = function (req, res) {
    res.send("Secret Post")
  };